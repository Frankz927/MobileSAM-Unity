TestTools
=========

**TestTools** is a Unity package of utility components for testing purposes.

At the moment, it only contains `ImageSource` providing a texture object with
several image sources (static image file, video file, webcam, etc.).
